# EventManagementSem2
Event management Project JAVA
